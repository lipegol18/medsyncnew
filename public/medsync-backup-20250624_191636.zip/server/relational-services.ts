import { db } from './db';
import { 
  medicalOrderCids, 
  medicalOrderOpmeItems, 
  medicalOrderSuppliers, 
  medicalOrderProcedures,
  procedures,
  type InsertMedicalOrderCid, 
  type InsertMedicalOrderOpmeItem, 
  type InsertMedicalOrderSupplier,
  type InsertMedicalOrderProcedure,
  type MedicalOrderProcedure
} from '@shared/schema';
import { eq, and } from 'drizzle-orm';

export class RelationalOrderService {
  // Gerenciar CIDs do pedido
  async updateOrderCids(orderId: number, cidIds: number[]): Promise<void> {
    // Remover CIDs existentes
    await db.delete(medicalOrderCids).where(eq(medicalOrderCids.orderId, orderId));
    
    // Inserir novos CIDs
    if (cidIds.length > 0) {
      const cidsToInsert: InsertMedicalOrderCid[] = cidIds.map(cidId => ({
        orderId,
        cidCodeId: cidId
      }));
      await db.insert(medicalOrderCids).values(cidsToInsert);
    }
  }

  async getOrderCids(orderId: number): Promise<number[]> {
    try {
      const orderCids = await db
        .select({ cidCodeId: medicalOrderCids.cidCodeId })
        .from(medicalOrderCids)
        .where(eq(medicalOrderCids.orderId, orderId));
      
      console.log(`Encontrados ${orderCids.length} CIDs para pedido ${orderId}`);
      return orderCids.map(oc => oc.cidCodeId);
    } catch (error) {
      console.error(`Erro ao buscar CIDs para pedido ${orderId}:`, error);
      return [];
    }
  }

  // Gerenciar OPME Items do pedido
  async updateOrderOpmeItems(orderId: number, opmeItems: { id: number; quantity: number }[]): Promise<void> {
    // Remover itens OPME existentes
    await db.delete(medicalOrderOpmeItems).where(eq(medicalOrderOpmeItems.orderId, orderId));
    
    // Inserir novos itens OPME
    if (opmeItems.length > 0) {
      const itemsToInsert: InsertMedicalOrderOpmeItem[] = opmeItems.map(item => ({
        orderId,
        opmeItemId: item.id,
        quantity: item.quantity
      }));
      await db.insert(medicalOrderOpmeItems).values(itemsToInsert);
    }
  }

  async getOrderOpmeItems(orderId: number): Promise<{ opmeItemId: number; quantity: number }[]> {
    try {
      const orderItems = await db
        .select({
          opmeItemId: medicalOrderOpmeItems.opmeItemId,
          quantity: medicalOrderOpmeItems.quantity
        })
        .from(medicalOrderOpmeItems)
        .where(eq(medicalOrderOpmeItems.orderId, orderId));
      
      console.log(`Encontrados ${orderItems.length} itens OPME para pedido ${orderId}`);
      return orderItems;
    } catch (error) {
      console.error(`Erro ao buscar itens OPME para pedido ${orderId}:`, error);
      return [];
    }
  }

  // Gerenciar Suppliers do pedido
  async updateOrderSuppliers(orderId: number, supplierIds: number[]): Promise<void> {
    // Remover fornecedores existentes
    await db.delete(medicalOrderSuppliers).where(eq(medicalOrderSuppliers.orderId, orderId));
    
    // Inserir novos fornecedores
    if (supplierIds.length > 0) {
      const suppliersToInsert: InsertMedicalOrderSupplier[] = supplierIds.map(supplierId => ({
        orderId,
        supplierId
      }));
      await db.insert(medicalOrderSuppliers).values(suppliersToInsert);
    }
  }

  async getOrderSuppliers(orderId: number): Promise<number[]> {
    try {
      const orderSuppliers = await db
        .select({ supplierId: medicalOrderSuppliers.supplierId })
        .from(medicalOrderSuppliers)
        .where(eq(medicalOrderSuppliers.orderId, orderId));
      
      console.log(`Encontrados ${orderSuppliers.length} fornecedores para pedido ${orderId}`);
      return orderSuppliers.map(os => os.supplierId);
    } catch (error) {
      console.error(`Erro ao buscar fornecedores para pedido ${orderId}:`, error);
      return [];
    }
  }

  // === GESTÃO DE PROCEDIMENTOS CBHPM ===
  
  async updateOrderProcedures(orderId: number, procedures: Array<{
    procedureId: number;
    quantityRequested: number;
    isMain?: boolean;
  }>): Promise<void> {
    console.log(`=== Atualizando procedimentos para pedido ${orderId} ===`);
    
    // Remover procedimentos existentes
    await db.delete(medicalOrderProcedures).where(eq(medicalOrderProcedures.orderId, orderId));
    
    // Inserir novos procedimentos
    if (procedures.length > 0) {
      // Garantir que apenas um procedimento seja marcado como principal
      let hasMain = false;
      const proceduresToInsert: InsertMedicalOrderProcedure[] = procedures.map((proc, index) => {
        const isMain = proc.isMain === true || (!hasMain && index === 0);
        if (isMain) hasMain = true;
        
        return {
          orderId,
          procedureId: proc.procedureId,
          quantityRequested: proc.quantityRequested,
          isMain,
          status: 'em_analise'
        };
      });
      
      await db.insert(medicalOrderProcedures).values(proceduresToInsert);
      console.log(`Inseridos ${proceduresToInsert.length} procedimentos`);
    }
  }

  async getOrderProcedures(orderId: number): Promise<Array<MedicalOrderProcedure & { procedure?: any }>> {
    try {
      const orderProcedures = await db
        .select()
        .from(medicalOrderProcedures)
        .where(eq(medicalOrderProcedures.orderId, orderId));
      
      // Enriquecer com dados do procedimento CBHPM
      const enrichedProcedures = await Promise.all(
        orderProcedures.map(async (proc) => {
          try {
            const [procedureData] = await db
              .select()
              .from(procedures)
              .where(eq(procedures.id, proc.procedureId));
            
            return {
              ...proc,
              procedure: procedureData || null
            };
          } catch (error) {
            console.error(`Erro ao buscar procedimento ${proc.procedureId}:`, error);
            return {
              ...proc,
              procedure: null
            };
          }
        })
      );
      
      console.log(`Encontrados ${enrichedProcedures.length} procedimentos para pedido ${orderId}`);
      return enrichedProcedures;
    } catch (error) {
      console.error(`Erro ao buscar procedimentos para pedido ${orderId}:`, error);
      return [];
    }
  }

  async addProcedureToOrder(orderId: number, procedureId: number, quantityRequested: number = 1): Promise<MedicalOrderProcedure | null> {
    try {
      // Verificar se procedimento já existe
      const existing = await db
        .select()
        .from(medicalOrderProcedures)
        .where(and(
          eq(medicalOrderProcedures.orderId, orderId),
          eq(medicalOrderProcedures.procedureId, procedureId)
        ));

      if (existing.length > 0) {
        throw new Error("Procedimento já existe neste pedido");
      }

      // Verificar se é o primeiro procedimento (será o principal)
      const existingProcedures = await db
        .select()
        .from(medicalOrderProcedures)
        .where(eq(medicalOrderProcedures.orderId, orderId));

      const isMain = existingProcedures.length === 0;

      const [newProcedure] = await db
        .insert(medicalOrderProcedures)
        .values({
          orderId,
          procedureId,
          quantityRequested,
          status: 'em_analise',
          isMain
        })
        .returning();

      return newProcedure;
    } catch (error) {
      console.error("Erro ao adicionar procedimento:", error);
      return null;
    }
  }

  async removeProcedureFromOrder(procedureOrderId: number): Promise<boolean> {
    try {
      const procedure = await db
        .select()
        .from(medicalOrderProcedures)
        .where(eq(medicalOrderProcedures.id, procedureOrderId));

      if (procedure.length === 0) {
        return false;
      }

      const wasMain = procedure[0].isMain;
      const orderId = procedure[0].orderId;

      // Remover procedimento
      await db
        .delete(medicalOrderProcedures)
        .where(eq(medicalOrderProcedures.id, procedureOrderId));

      // Se era principal, promover outro procedimento
      if (wasMain) {
        const remainingProcedures = await db
          .select()
          .from(medicalOrderProcedures)
          .where(eq(medicalOrderProcedures.orderId, orderId));

        if (remainingProcedures.length > 0) {
          await db
            .update(medicalOrderProcedures)
            .set({ isMain: true })
            .where(eq(medicalOrderProcedures.id, remainingProcedures[0].id));
        }
      }

      return true;
    } catch (error) {
      console.error("Erro ao remover procedimento:", error);
      return false;
    }
  }

  // Limpar todos os relacionamentos de um pedido (incluindo procedimentos)
  async clearOrderRelations(orderId: number): Promise<void> {
    await Promise.all([
      db.delete(medicalOrderCids).where(eq(medicalOrderCids.orderId, orderId)),
      db.delete(medicalOrderOpmeItems).where(eq(medicalOrderOpmeItems.orderId, orderId)),
      db.delete(medicalOrderSuppliers).where(eq(medicalOrderSuppliers.orderId, orderId)),
      db.delete(medicalOrderProcedures).where(eq(medicalOrderProcedures.orderId, orderId))
    ]);
  }
}

export const relationalOrderService = new RelationalOrderService();